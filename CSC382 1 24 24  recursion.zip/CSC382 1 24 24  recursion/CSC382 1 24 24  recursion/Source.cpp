#include <iostream>
using namespace std;

void blastoff(int num);
int main()
{
	for (int i = 10; i > 0; i--)
	{
		cout << "Countdown " << i << endl;

	}
	cout << "Blastoff!" << endl;
	blastoff(10);


}
void blastoff(int count)
{
	// exit condition
	if (count > 0)
	{
		cout << "Recursion Blastoff = " << count << endl;
		count--;
		blastoff(count);
	}
	else
	{
		cout << "Recursion Blastoff" << endl;
		return;
	}

}
