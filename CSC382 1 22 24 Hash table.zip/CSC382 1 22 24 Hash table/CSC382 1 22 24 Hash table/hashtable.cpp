// Hash hashT using chains
#include<iostream> 
#include <list> 
using namespace std;

class HT
{
	int numIndexes;
	list<int>* hashT;

public:
	HT(int V);
	void insertItem(int key);
	int hash(int x);
	void displayHash();


};

void HT::displayHash()
{
	for (int i = 0; i < numIndexes; i++)
	{
		cout << i;
		for (auto x : hashT[i])
		{
			cout << "-->" << x;
		}
		cout << endl;
	}

}

HT::HT(int b)
{
	this->numIndexes = b;
	hashT = new list<int>[numIndexes];

}


void HT::insertItem(int key)
{
	int index = hash(key);
	hashT[index].push_back(key);

}

int HT::hash(int num)
{
	return (num % 599);
}

int main()
{
	int numInd = 1000;
	int rnd;

	srand(time(NULL));

	HT JillHash(numInd);

	for (int i = 0; i < numInd - 1; i++)
	{
		rnd = rand() % 100 +1;
		JillHash.insertItem(rnd);

	}
	JillHash.insertItem(42);
	JillHash.displayHash();


}