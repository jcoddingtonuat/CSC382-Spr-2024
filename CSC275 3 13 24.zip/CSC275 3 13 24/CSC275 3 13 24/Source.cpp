#include <iostream>
#include <thread>
#include <mutex>

using namespace std;
//global
static const int numThreads = 5;
mutex Mlock;
int localTID = 0;

void callFromThread(int tid)
{
	Mlock.lock();
	cout << "inside function for thread" << endl;
	localTID = tid;
	cout << "thread id = " << localTID;
	Mlock.unlock();
}


class threadClass {
public:
	void operator()(int n) {
			Mlock.lock();
			cout << "Thread 2 thread object" << endl;
			Mlock.unlock();
	}
};

int main()
{
	//create 
	thread exampleThreads[numThreads];

	for (int i = 0; i < numThreads; i++)
	{
		exampleThreads[i] = thread(callFromThread, i);
	}
	cout << "threads created and associated with a function" << endl;

	for (int i = 0; i < numThreads; i++)
	{
		if (exampleThreads[i].joinable())
		{
			exampleThreads[i].join();
		}
		else
		{
			cout << "error joining thread " << i << endl;
		}

	}
	cout << "join completed" << endl;


	thread t2(threadClass(), 42);
	if (t2.joinable())
	{
		t2.join();
	}
	else
	{
		cout << "t2 could not join" << endl;
	}
	


	return 0;
}